# Sathvick (19bec009)
# Surya teja (19BEC030)
import pandas as pd
import os
print("For Admin  click 1")
print("For User click 2 ")
n=int(input("Type your preference"))
 
dataA ={
        'Hospitals Name': ['a','b','c','d','e','f','g','h'],
        'Donors Name' : ['abc','ret','fdtf','gfg','ghfgh','hasgf','fcvbv','fagd'],
        'Blood group':['A','A','A','A','A','A','A','A'],
        'Branch':['a','b','c','d','e','f','g','h'],
        'Phone Number':[3546,6555,65464,6546546,5454654,654654,654646,4654,]
       
    }
    
dataB ={
        'Hospitals Name': ['a','b','c','d','e','f','g','h'],
        'Donors Name' : ['abc','ret','fdtf','gfg','ghfgh','hasgf','fcvbv','fagd'],
        'Blood group':['B','B','B','B','B','B','B','B'],
        'Branch':['a','b','c','d','e','f','g','h'],
        'Phone Number':[3546,6555,65464,6546546,5454654,654654,654646,4654,]
       
    }
    
dataO ={
        'Hospitals Name': ['a','b','c','d','e','f','g','h'],
        'Donors Name' : ['abc','ret','fdtf','gfg','ghfgh','hasgf','fcvbv','fagd'],
        'Blood group':['O','O','O','O','O','O','O','O'],
        'Branch':['a','b','c','d','e','f','g','h'],
        'Phone Number':[3546,6555,65464,6546546,5454654,654654,654646,4654,]
       
    }
 
dataAB ={
        'Hospitals Name': ['a','b','c','d','e','f','g','h'],
        'Donors Name' : ['abc','ret','fdtf','gfg','ghfgh','hasgf','fcvbv','fagd'],
        'Blood group':['AB','AB','AB','AB','AB','AB','AB','AB'],
        'Branch':['a','b','c','d','e','f','g','h'],
        'Phone Number':[3546,6555,65464,6546546,5454654,654654,654646,4654,]
       
    }
if n==1:
    print(pd.DataFrame(dataA))  
    print(pd.DataFrame(dataB))  
    print(pd.DataFrame(dataO))
    print("Rarest blood group")
    print(pd.DataFrame(dataAB))
else:
    print("For blood group A type A")
    print("For blood group B type B")
    print("For blood group O type O")
    print("For blood group AB type AB")
    d=input("Type Your Requirement")
    if d=="A" :
        print(pd.DataFrame(dataA))
    elif d=="B" :
        print(pd.DataFrame(dataB))
    elif d=="O" :   
          print(pd.DataFrame(dataO))
    elif d=="AB" :
        print(pd.DataFrame(dataAB))
 



#OUTPUT :
#For User:
#PS C:\Users\ADMIN> & C:/ProgramData/Anaconda3/python.exe c:/Users/ADMIN/Desktop/souravhackathon.py
#For Admin  click 1
#For User click 2 
#Type your preference2
#For blood group A type A
#For blood group B type B
#For blood group O type O
#For blood group AB type AB
#Type Your RequirementAB
#  Hospitals Name Donors Name Blood group Branch  Phone Number
#0              a         abc          AB      a          3546
#1              b         ret          AB      b          6555
#2              c        fdtf          AB      c         65464
#3              d         gfg          AB      d       6546546
#4              e       ghfgh          AB      e       5454654
#5              f       hasgf          AB      f        654654
#6              g       fcvbv          AB      g        654646
#7              h        fagd          AB      h          4654
#PS C:\Users\ADMIN>
#For Admin:
#PS C:\Users\ADMIN> & C:/ProgramData/Anaconda3/python.exe c:/Users/ADMIN/Desktop/souravhackathon.py
#For Admin  click 1
#For User click 2 
#Type your preference1
#  Hospitals Name Donors Name Blood group Branch  Phone Number
#0              a         abc           A      a          3546
#1              b         ret           A      b          6555
#2              c        fdtf           A      c         65464
#3              d         gfg           A      d       6546546
#4              e       ghfgh           A      e       5454654
#5              f       hasgf           A      f        654654
#6              g       fcvbv           A      g        654646
#7              h        fagd           A      h          4654
#  Hospitals Name Donors Name Blood group Branch  Phone Number
#0              a         abc           B      a          3546
#1              b         ret           B      b          6555
#2              c        fdtf           B      c         65464
#3              d         gfg           B      d       6546546
#4              e       ghfgh           B      e       5454654
#5              f       hasgf           B      f        654654
#6              g       fcvbv           B      g        654646
#7              h        fagd           B      h          4654
#  Hospitals Name Donors Name Blood group Branch  Phone Number
#0              a         abc           O      a          3546
#1              b         ret           O      b          6555
#2              c        fdtf           O      c         65464
#3              d         gfg           O      d       6546546
#4              e       ghfgh           O      e       5454654
#5              f       hasgf           O      f        654654
#6              g       fcvbv           O      g        654646
#7              h        fagd           O      h          4654
#Rarest blood group
#  Hospitals Name Donors Name Blood group Branch  Phone Number
#0              a         abc          AB      a          3546
#1              b         ret          AB      b          6555
#2              c        fdtf          AB      c         65464
#3              d         gfg          AB      d       6546546
#4              e       ghfgh          AB      e       5454654
#5              f       hasgf          AB      f        654654
#6              g       fcvbv          AB      g        654646
#7              h        fagd          AB      h          4654
